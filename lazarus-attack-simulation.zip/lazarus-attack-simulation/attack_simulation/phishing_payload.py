# Simulação de payload malicioso via PDF
print('Payload enviado via PDF')