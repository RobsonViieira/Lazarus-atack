# Simula acesso indevido a carteira
print('Chave privada coletada')