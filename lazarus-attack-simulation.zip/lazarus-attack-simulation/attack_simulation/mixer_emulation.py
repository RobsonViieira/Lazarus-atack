# Simula mixer para lavagem
print('Transações dispersas')