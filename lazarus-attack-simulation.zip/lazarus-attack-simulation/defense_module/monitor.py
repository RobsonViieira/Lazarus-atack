# Monitora transações em tempo real
print('Monitoramento iniciado')