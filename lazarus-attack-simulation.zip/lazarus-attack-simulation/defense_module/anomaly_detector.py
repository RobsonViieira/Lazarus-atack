# Detecta anomalias nas transações
print('Anomalia detectada')