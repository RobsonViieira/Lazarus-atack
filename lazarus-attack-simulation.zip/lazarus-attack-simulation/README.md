# Lazarus Attack Simulation
Projeto educacional que simula táticas do grupo Lazarus para conscientização em segurança cripto.